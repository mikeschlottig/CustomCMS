
export interface UserDetails {
  active: boolean;
  client_id: string; 
  sub: string;
  user_uuid: string;
  email: string;
}
