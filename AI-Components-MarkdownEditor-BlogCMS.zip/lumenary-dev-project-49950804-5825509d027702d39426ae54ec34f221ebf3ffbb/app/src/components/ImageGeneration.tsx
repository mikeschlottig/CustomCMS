import { Image as ImageIcon, Trash2, Download, Copy, Loader } from "lucide-react";
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { 
  imageGenerationGenerateImage, 
  imageGenerationGetGeneratedImages,
  imageGenerationDeleteGeneratedImage 
} from '@/lib/sdk'
import type { GeneratedImage } from '@/lib/sdk'
import { Image as ImageIcon, Loader2, Trash2, Download, Copy } from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

export default function ImageGeneration() {
  const [images, setImages] = useState<GeneratedImage[]>([])
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null)
  
  const [prompt, setPrompt] = useState('')
  const [size, setSize] = useState('1024x1024')
  const [model, setModel] = useState('dall-e-3')

  const fetchImages = async () => {
    try {
      const response = await imageGenerationGetGeneratedImages({ body: {} })
      if (response.data) {
        setImages(response.data)
      }
    } catch (error) {
      console.error('Error fetching images:', error)
      toast.error('Failed to load images')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchImages()
  }, [])

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt')
      return
    }

    setGenerating(true)
    try {
      const response = await imageGenerationGenerateImage({
        body: {
          prompt: prompt.trim(),
          size,
          model,
          blog_post_id: null
        }
      })
      
      if (response.data) {
        setImages(prev => [response.data!, ...prev])
        setPrompt('')
        toast.success('Image generated successfully!')
      }
    } catch (error) {
      console.error('Error generating image:', error)
      toast.error('Failed to generate image')
    } finally {
      setGenerating(false)
    }
  }

  const handleDelete = async (imageId: string) => {
    try {
      const response = await imageGenerationDeleteGeneratedImage({
        body: { image_id: imageId }
      })
      
      if (response.data) {
        setImages(prev => prev.filter(img => img.id !== imageId))
        toast.success('Image deleted successfully')
      }
    } catch (error) {
      console.error('Error deleting image:', error)
      toast.error('Failed to delete image')
    }
  }

  const copyImageUrl = (url: string) => {
    navigator.clipboard.writeText(url)
    toast.success('Image URL copied to clipboard')
  }

  const downloadImage = async (url: string, filename: string) => {
    try {
      const response = await fetch(url)
      const blob = await response.blob()
      const downloadUrl = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = downloadUrl
      link.download = filename
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(downloadUrl)
      toast.success('Image downloaded')
    } catch (error) {
      console.error('Error downloading image:', error)
      toast.error('Failed to download image')
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">AI Image Generation</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-0">
                <div className="aspect-square bg-muted animate-pulse rounded-t-lg"></div>
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-muted rounded animate-pulse"></div>
                  <div className="h-3 bg-muted rounded animate-pulse w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">AI Image Generation</h1>
        <p className="text-muted-foreground">{images.length} images generated</p>
      </div>

      {/* Generation Form */}
      <Card>
        <CardHeader>
          <CardTitle>Generate New Image</CardTitle>
          <CardDescription>Create AI-generated images using DALL-E 3 or GPT Image 1</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <Textarea
                placeholder="Describe the image you want to generate..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[100px]"
                maxLength={4000}
              />
              <p className="text-sm text-muted-foreground mt-1">
                {prompt.length}/4000 characters
              </p>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Model</label>
                <Select value={model} onValueChange={setModel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dall-e-3">DALL-E 3 (Fast)</SelectItem>
                    <SelectItem value="gpt-image-1">GPT Image 1 (High Quality)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Size</label>
                <Select value={size} onValueChange={setSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1024x1024">Square (1024×1024)</SelectItem>
                    {model === 'dall-e-3' ? (
                      <>
                        <SelectItem value="1792x1024">Landscape (1792×1024)</SelectItem>
                        <SelectItem value="1024x1792">Portrait (1024×1792)</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="1536x1024">Landscape (1536×1024)</SelectItem>
                        <SelectItem value="1024x1536">Portrait (1024×1536)</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={generating || !prompt.trim()}
                className="w-full"
              >
                {generating ? (
                  <>
                    <Loader className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <ImageIcon className="h-4 w-4 mr-2" />
                    Generate Image
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Images Gallery */}
      {images.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No images generated yet</h3>
            <p className="text-muted-foreground mb-4">Create your first AI-generated image using the form above</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image) => (
            <Card key={image.id} className="overflow-hidden group">
              <div className="relative">
                <img
                  src={image.image_path}
                  alt={image.alt_text || 'Generated image'}
                  className="w-full aspect-square object-cover cursor-pointer transition-transform group-hover:scale-105"
                  onClick={() => setSelectedImage(image)}
                />
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => copyImageUrl(image.image_path)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => downloadImage(image.image_path, `image-${image.id}.png`)}
                    >
                      <Download className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(image.id!)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="absolute bottom-2 left-2">
                  <Badge variant="secondary">{image.model_used}</Badge>
                </div>
              </div>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {image.prompt}
                </p>
                <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                  <span>{image.size}</span>
                  <span>{new Date(image.created_at!).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Image Preview Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Generated Image</DialogTitle>
          </DialogHeader>
          {selectedImage && (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={selectedImage.image_path}
                  alt={selectedImage.alt_text || 'Generated image'}
                  className="w-full max-h-[500px] object-contain rounded-lg"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge>{selectedImage.model_used}</Badge>
                  <Badge variant="outline">{selectedImage.size}</Badge>
                  <Badge variant="outline">
                    {new Date(selectedImage.created_at!).toLocaleDateString()}
                  </Badge>
                </div>
                <p className="text-sm">
                  <strong>Prompt:</strong> {selectedImage.prompt}
                </p>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyImageUrl(selectedImage.image_path)}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy URL
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => downloadImage(selectedImage.image_path, `image-${selectedImage.id}.png`)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}