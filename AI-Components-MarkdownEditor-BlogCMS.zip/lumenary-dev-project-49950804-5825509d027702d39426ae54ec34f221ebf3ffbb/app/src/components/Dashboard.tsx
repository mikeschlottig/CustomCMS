import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  blogManagementGetBlogPosts, 
  imageGenerationGetGeneratedImages,
  siteManagementGetPublishedSites 
} from '@/lib/sdk'
import type { BlogPost, GeneratedImage, PublishedSite } from '@/lib/sdk'
import { FileText, Image as ImageIcon, Globe, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalPosts: 0,
    publishedPosts: 0,
    totalImages: 0,
    totalSites: 0
  })
  const [recentPosts, setRecentPosts] = useState<BlogPost[]>([])
  const [recentImages, setRecentImages] = useState<GeneratedImage[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Fetch stats
        const [allPosts, publishedPosts, images, sites] = await Promise.all([
          blogManagementGetBlogPosts({ body: { limit: 100, offset: 0 } }),
          blogManagementGetBlogPosts({ body: { status: 'published', limit: 100, offset: 0 } }),
          imageGenerationGetGeneratedImages({ body: {} }),
          siteManagementGetPublishedSites()
        ])

        setStats({
          totalPosts: allPosts.data?.length || 0,
          publishedPosts: publishedPosts.data?.length || 0,
          totalImages: images.data?.length || 0,
          totalSites: sites.data?.length || 0
        })

        // Set recent data
        setRecentPosts(allPosts.data?.slice(0, 5) || [])
        setRecentImages(images.data?.slice(0, 4) || [])
      } catch (error) {
        console.error('Error fetching dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [])

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="w-8 h-8 bg-muted rounded"></div>
                  <div className="w-16 h-8 bg-muted rounded"></div>
                  <div className="w-24 h-4 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="flex gap-2">
          <Button asChild>
            <Link to="/editor">New Post</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/images">Generate Image</Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <FileText className="h-8 w-8 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{stats.totalPosts}</p>
                <p className="text-sm text-muted-foreground">Total Posts</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{stats.publishedPosts}</p>
                <p className="text-sm text-muted-foreground">Published</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <ImageIcon className="h-8 w-8 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{stats.totalImages}</p>
                <p className="text-sm text-muted-foreground">Generated Images</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Globe className="h-8 w-8 text-orange-500" />
              <div>
                <p className="text-2xl font-bold">{stats.totalSites}</p>
                <p className="text-sm text-muted-foreground">Published Sites</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Posts */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Posts</CardTitle>
            <CardDescription>Your latest blog posts</CardDescription>
          </CardHeader>
          <CardContent>
            {recentPosts.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">No posts yet</p>
                <Button asChild>
                  <Link to="/editor">Create your first post</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {recentPosts.map((post) => (
                  <div key={post.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <h4 className="font-medium">{post.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {post.status === 'published' ? 'Published' : 'Draft'} • {new Date(post.created_at!).toLocaleDateString()}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <Link to={`/editor/${post.id}`}>Edit</Link>
                    </Button>
                  </div>
                ))}
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/posts">View all posts</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Images */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Images</CardTitle>
            <CardDescription>Your latest AI-generated images</CardDescription>
          </CardHeader>
          <CardContent>
            {recentImages.length === 0 ? (
              <div className="text-center py-8">
                <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">No images generated yet</p>
                <Button asChild>
                  <Link to="/images">Generate your first image</Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {recentImages.map((image) => (
                  <div key={image.id} className="group relative aspect-square">
                    <img
                      src={image.image_path}
                      alt={image.alt_text || 'Generated image'}
                      className="w-full h-full object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                      <p className="text-white text-xs text-center p-2">
                        {image.prompt.substring(0, 50)}...
                      </p>
                    </div>
                  </div>
                ))}
                <div className="col-span-2">
                  <Button variant="outline" className="w-full" asChild>
                    <Link to="/images">View all images</Link>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}