import { Routes, Route } from 'react-router-dom'
import { RootLayout } from '@/components/layout/RootLayout'
import Dashboard from '@/components/Dashboard'
import ImageGeneration from '@/components/ImageGeneration'
import BlogPosts from '@/components/BlogPosts'
import BlogEditor from '@/components/BlogEditor'
import SiteManagement from '@/components/SiteManagement'
import Settings from '@/components/Settings'
import MainLayout from '@/components/layout/MainLayout'

export default function Router() {
  return (
    <RootLayout>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="images" element={<ImageGeneration />} />
          <Route path="posts" element={<BlogPosts />} />
          <Route path="editor" element={<BlogEditor />} />
          <Route path="editor/:postId" element={<BlogEditor />} />
          <Route path="sites" element={<SiteManagement />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </RootLayout>
  )
}