import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  blogManagementCreateBlogPost, 
  blogManagementUpdateBlogPost,
  blogManagementGetBlogPost,
  imageGenerationGetGeneratedImages
} from '@/lib/sdk'
import type { BlogPost, GeneratedImage } from '@/lib/sdk'
import { 
  Save, 
  Eye, 
  Globe, 
  Image as ImageIcon, 
  X,
  Plus,
  ArrowLeft,
  Bold,
  Italic,
  Link as LinkIcon,
  List,
  ListOrdered,
  Quote,
  Code,
  Heading1,
  Heading2,
  Heading3
} from 'lucide-react'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

export default function BlogEditor() {
  const { postId } = useParams()
  const navigate = useNavigate()
  const isEditing = !!postId
  
  const [post, setPost] = useState<Partial<BlogPost>>({
    title: '',
    content: '',
    excerpt: '',
    tags: [],
    categories: [],
    meta_title: '',
    meta_description: '',
    author_name: 'Admin',
    status: 'draft'
  })
  
  const [loading, setLoading] = useState(isEditing)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState('edit')
  const [images, setImages] = useState<GeneratedImage[]>([])
  const [showImagePicker, setShowImagePicker] = useState(false)
  const [newTag, setNewTag] = useState('')
  const [newCategory, setNewCategory] = useState('')

  // Load post if editing
  useEffect(() => {
    if (isEditing && postId) {
      const loadPost = async () => {
        try {
          const response = await blogManagementGetBlogPost({
            body: { post_id: postId }
          })
          
          if (response.data) {
            setPost(response.data)
          } else {
            toast.error('Post not found')
            navigate('/posts')
          }
        } catch (error) {
          console.error('Error loading post:', error)
          toast.error('Failed to load post')
          navigate('/posts')
        } finally {
          setLoading(false)
        }
      }
      
      loadPost()
    }
  }, [isEditing, postId, navigate])

  // Load images for picker
  useEffect(() => {
    const loadImages = async () => {
      try {
        const response = await imageGenerationGetGeneratedImages({ body: {} })
        if (response.data) {
          setImages(response.data)
        }
      } catch (error) {
        console.error('Error loading images:', error)
      }
    }
    
    loadImages()
  }, [])

  const handleSave = async (publish = false) => {
    if (!post.title?.trim()) {
      toast.error('Please enter a title')
      return
    }
    
    if (!post.content?.trim()) {
      toast.error('Please enter some content')
      return
    }

    setSaving(true)
    try {
      const postData = {
        ...post,
        status: publish ? 'published' : 'draft'
      }
      
      let response
      if (isEditing) {
        response = await blogManagementUpdateBlogPost({
          body: {
            post_id: postId!,
            ...postData
          }
        })
      } else {
        response = await blogManagementCreateBlogPost({
          body: postData as any
        })
      }
      
      if (response.data) {
        toast.success(publish ? 'Post published successfully!' : 'Post saved successfully!')
        if (!isEditing) {
          navigate(`/editor/${response.data.id}`)
        } else {
          setPost(response.data)
        }
      }
    } catch (error) {
      console.error('Error saving post:', error)
      toast.error('Failed to save post')
    } finally {
      setSaving(false)
    }
  }

  const insertMarkdown = (markdown: string) => {
    const textarea = document.querySelector('textarea[data-content="true"]') as HTMLTextAreaElement
    if (!textarea) return
    
    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const content = post.content || ''
    const newContent = content.substring(0, start) + markdown + content.substring(end)
    
    setPost(prev => ({ ...prev, content: newContent }))
    
    // Reset cursor position
    setTimeout(() => {
      textarea.focus()
      textarea.setSelectionRange(start + markdown.length, start + markdown.length)
    }, 0)
  }

  const addTag = () => {
    if (newTag.trim() && !post.tags?.includes(newTag.trim())) {
      setPost(prev => ({
        ...prev,
        tags: [...(prev.tags || []), newTag.trim()]
      }))
      setNewTag('')
    }
  }

  const removeTag = (tag: string) => {
    setPost(prev => ({
      ...prev,
      tags: prev.tags?.filter(t => t !== tag) || []
    }))
  }

  const addCategory = () => {
    if (newCategory.trim() && !post.categories?.includes(newCategory.trim())) {
      setPost(prev => ({
        ...prev,
        categories: [...(prev.categories || []), newCategory.trim()]
      }))
      setNewCategory('')
    }
  }

  const removeCategory = (category: string) => {
    setPost(prev => ({
      ...prev,
      categories: prev.categories?.filter(c => c !== category) || []
    }))
  }

  const selectFeaturedImage = (image: GeneratedImage) => {
    setPost(prev => ({ ...prev, featured_image_id: image.id }))
    setShowImagePicker(false)
    toast.success('Featured image selected')
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate('/posts')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Posts
          </Button>
          <h1 className="text-3xl font-bold">Loading...</h1>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-muted rounded"></div>
              <div className="h-32 bg-muted rounded"></div>
              <div className="h-64 bg-muted rounded"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate('/posts')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Posts
          </Button>
          <h1 className="text-3xl font-bold">
            {isEditing ? 'Edit Post' : 'New Post'}
          </h1>
          {post.status && (
            <Badge variant={post.status === 'published' ? 'default' : 'outline'}>
              {post.status}
            </Badge>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => handleSave(false)}
            disabled={saving}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Draft
          </Button>
          <Button 
            onClick={() => handleSave(true)}
            disabled={saving}
          >
            <Globe className="h-4 w-4 mr-2" />
            {post.status === 'published' ? 'Update' : 'Publish'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Editor */}
        <div className="lg:col-span-2 space-y-6">
          {/* Title and Excerpt */}
          <Card>
            <CardHeader>
              <CardTitle>Post Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Input
                  placeholder="Post title..."
                  value={post.title || ''}
                  onChange={(e) => setPost(prev => ({ ...prev, title: e.target.value }))}
                  className="text-lg font-medium"
                />
              </div>
              <div>
                <Textarea
                  placeholder="Brief excerpt or summary..."
                  value={post.excerpt || ''}
                  onChange={(e) => setPost(prev => ({ ...prev, excerpt: e.target.value }))}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Content Editor */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Content</CardTitle>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="edit">Edit</TabsTrigger>
                    <TabsTrigger value="preview">Preview</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsContent value="edit" className="space-y-4">
                  {/* Markdown Toolbar */}
                  <div className="flex flex-wrap gap-1 p-2 border border-border rounded-md bg-muted/50">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('**bold text**')}
                      title="Bold"
                    >
                      <Bold className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('*italic text*')}
                      title="Italic"
                    >
                      <Italic className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('# ')}
                      title="Heading 1"
                    >
                      <Heading1 className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('## ')}
                      title="Heading 2"
                    >
                      <Heading2 className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('### ')}
                      title="Heading 3"
                    >
                      <Heading3 className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('[link text](url)')}
                      title="Link"
                    >
                      <LinkIcon className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('- ')}
                      title="Bullet List"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('1. ')}
                      title="Numbered List"
                    >
                      <ListOrdered className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('> ')}
                      title="Quote"
                    >
                      <Quote className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('`code`')}
                      title="Inline Code"
                    >
                      <Code className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => insertMarkdown('![alt text](image-url)')}
                      title="Image"
                    >
                      <ImageIcon className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <Textarea
                    data-content="true"
                    placeholder="Start writing your post content in Markdown..."
                    value={post.content || ''}
                    onChange={(e) => setPost(prev => ({ ...prev, content: e.target.value }))}
                    className="min-h-[400px] font-mono"
                  />
                </TabsContent>
                
                <TabsContent value="preview">
                  <div className="min-h-[400px] p-4 border border-border rounded-md bg-background">
                    {post.content ? (
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        <ReactMarkdown>{post.content}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="text-muted-foreground">Nothing to preview yet. Add some content in the Edit tab.</p>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Featured Image */}
          <Card>
            <CardHeader>
              <CardTitle>Featured Image</CardTitle>
            </CardHeader>
            <CardContent>
              {post.featured_image_path ? (
                <div className="space-y-2">
                  <img 
                    src={post.featured_image_path} 
                    alt="Featured" 
                    className="w-full aspect-video object-cover rounded-lg"
                  />
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setPost(prev => ({ ...prev, featured_image_path: undefined, featured_image_id: undefined }))}
                  >
                    Remove Image
                  </Button>
                </div>
              ) : (
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setShowImagePicker(true)}
                >
                  <ImageIcon className="h-4 w-4 mr-2" />
                  Select Image
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Tags */}
          <Card>
            <CardHeader>
              <CardTitle>Tags</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <Input
                  placeholder="Add tag..."
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addTag()}
                />
                <Button onClick={addTag} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-1">
                {post.tags?.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tag}
                    <button 
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Categories */}
          <Card>
            <CardHeader>
              <CardTitle>Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <Input
                  placeholder="Add category..."
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addCategory()}
                />
                <Button onClick={addCategory} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-1">
                {post.categories?.map((category, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {category}
                    <button 
                      onClick={() => removeCategory(category)}
                      className="ml-1 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* SEO */}
          <Card>
            <CardHeader>
              <CardTitle>SEO Settings</CardTitle>
              <CardDescription>Optimize for search engines</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Meta Title</label>
                <Input
                  placeholder="SEO title (defaults to post title)"
                  value={post.meta_title || ''}
                  onChange={(e) => setPost(prev => ({ ...prev, meta_title: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Meta Description</label>
                <Textarea
                  placeholder="Brief description for search results"
                  value={post.meta_description || ''}
                  onChange={(e) => setPost(prev => ({ ...prev, meta_description: e.target.value }))}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Image Picker Dialog */}
      <Dialog open={showImagePicker} onOpenChange={setShowImagePicker}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Select Featured Image</DialogTitle>
            <DialogDescription>
              Choose from your generated images or generate a new one
            </DialogDescription>
          </DialogHeader>
          
          {images.length === 0 ? (
            <div className="text-center py-8">
              <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No images available</p>
              <Button onClick={() => navigate('/images')}>Generate Images</Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {images.map((image) => (
                <div 
                  key={image.id}
                  className="group cursor-pointer"
                  onClick={() => selectFeaturedImage(image)}
                >
                  <img
                    src={image.image_path}
                    alt={image.alt_text || 'Generated image'}
                    className="w-full aspect-square object-cover rounded-lg group-hover:ring-2 group-hover:ring-primary transition-all"
                  />
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                    {image.prompt}
                  </p>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}