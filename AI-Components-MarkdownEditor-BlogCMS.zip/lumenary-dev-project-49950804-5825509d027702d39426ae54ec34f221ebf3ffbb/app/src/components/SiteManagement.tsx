import { Globe, Plus, Settings, ExternalLink, Check, Copy, Trash2, TriangleAlert, CreditCard } from "lucide-react";
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  siteManagementCreatePublishedSite,
  siteManagementGetPublishedSites,
  siteManagementUpdatePublishedSite,
  siteManagementAddCustomDomain,
  siteManagementVerifyCustomDomain,
  siteManagementGetSiteDomains
} from '@/lib/sdk'
import type { PublishedSite, CustomDomain } from '@/lib/sdk'
import { 
  Globe, 
  Plus, 
  Settings, 
  ExternalLink, 
  Check, 
  AlertTriangle,
  Copy,
  Edit3,
  Trash2
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'

export default function SiteManagement() {
  const [sites, setSites] = useState<PublishedSite[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedSite, setSelectedSite] = useState<PublishedSite | null>(null)
  const [domains, setDomains] = useState<CustomDomain[]>([])
  const [showCreateSite, setShowCreateSite] = useState(false)
  const [showEditSite, setShowEditSite] = useState(false)
  const [showDomainDialog, setShowDomainDialog] = useState(false)
  
  const [newSite, setNewSite] = useState({
    site_name: '',
    subdomain: '',
    site_description: '',
    site_title: '',
    site_tagline: '',
    theme: 'default'
  })
  
  const [newDomain, setNewDomain] = useState('')

  const fetchSites = async () => {
    try {
      const response = await siteManagementGetPublishedSites()
      if (response.data) {
        setSites(response.data)
        if (response.data.length > 0 && !selectedSite) {
          setSelectedSite(response.data[0])
        }
      }
    } catch (error) {
      console.error('Error fetching sites:', error)
      toast.error('Failed to load sites')
    } finally {
      setLoading(false)
    }
  }

  const fetchDomains = async (siteId: string) => {
    try {
      const response = await siteManagementGetSiteDomains({
        body: { site_id: siteId }
      })
      if (response.data) {
        setDomains(response.data)
      }
    } catch (error) {
      console.error('Error fetching domains:', error)
    }
  }

  useEffect(() => {
    fetchSites()
  }, [])

  useEffect(() => {
    if (selectedSite) {
      fetchDomains(selectedSite.id!)
    }
  }, [selectedSite])

  const handleCreateSite = async () => {
    if (!newSite.site_name.trim() || !newSite.subdomain.trim()) {
      toast.error('Please fill in required fields')
      return
    }

    try {
      const response = await siteManagementCreatePublishedSite({
        body: newSite
      })
      
      if (response.data) {
        setSites(prev => [response.data!, ...prev])
        setSelectedSite(response.data)
        setNewSite({
          site_name: '',
          subdomain: '',
          site_description: '',
          site_title: '',
          site_tagline: '',
          theme: 'default'
        })
        setShowCreateSite(false)
        toast.success('Site created successfully!')
      }
    } catch (error) {
      console.error('Error creating site:', error)
      toast.error('Failed to create site')
    }
  }

  const handleUpdateSite = async () => {
    if (!selectedSite) return

    try {
      const response = await siteManagementUpdatePublishedSite({
        body: {
          site_id: selectedSite.id!,
          site_name: selectedSite.site_name,
          site_description: selectedSite.site_description,
          site_title: selectedSite.site_title,
          site_tagline: selectedSite.site_tagline,
          theme: selectedSite.theme,
          is_active: selectedSite.is_active
        }
      })
      
      if (response.data) {
        setSites(prev => prev.map(site => 
          site.id === selectedSite.id ? response.data! : site
        ))
        setSelectedSite(response.data)
        setShowEditSite(false)
        toast.success('Site updated successfully!')
      }
    } catch (error) {
      console.error('Error updating site:', error)
      toast.error('Failed to update site')
    }
  }

  const handleAddDomain = async () => {
    if (!selectedSite || !newDomain.trim()) {
      toast.error('Please enter a domain name')
      return
    }

    try {
      const response = await siteManagementAddCustomDomain({
        body: {
          site_id: selectedSite.id!,
          domain: newDomain.trim()
        }
      })
      
      if (response.data) {
        setDomains(prev => [response.data!, ...prev])
        setNewDomain('')
        setShowDomainDialog(false)
        toast.success('Domain added successfully!')
      }
    } catch (error) {
      console.error('Error adding domain:', error)
      toast.error('Failed to add domain')
    }
  }

  const handleVerifyDomain = async (domainId: string) => {
    try {
      const response = await siteManagementVerifyCustomDomain({
        body: { domain_id: domainId }
      })
      
      if (response.data) {
        setDomains(prev => prev.map(domain => 
          domain.id === domainId ? response.data! : domain
        ))
        toast.success('Domain verified successfully!')
      }
    } catch (error) {
      console.error('Error verifying domain:', error)
      toast.error('Failed to verify domain')
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
      case 'active':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">Active</Badge>
      case 'pending':
        return <Badge variant="outline">Pending</Badge>
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Site Management</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-4">
                <div className="h-6 bg-muted rounded"></div>
                <div className="h-4 bg-muted rounded"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Site Management</h1>
        <Button onClick={() => setShowCreateSite(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Site
        </Button>
      </div>

      {sites.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Globe className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No sites created yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first published site to start sharing your blog posts
            </p>
            <Button onClick={() => setShowCreateSite(true)}>
              Create your first site
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sites List */}
          <Card>
            <CardHeader>
              <CardTitle>Published Sites</CardTitle>
              <CardDescription>Manage your published blog sites</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {sites.map((site) => (
                <div
                  key={site.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedSite?.id === site.id
                      ? 'bg-primary/10 border-primary'
                      : 'hover:bg-accent'
                  }`}
                  onClick={() => setSelectedSite(site)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">{site.site_name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {site.subdomain}.blog.com
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(site.is_active ? 'active' : 'inactive')}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Site Details */}
          {selectedSite && (
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{selectedSite.site_name}</CardTitle>
                      <CardDescription>
                        {selectedSite.site_description || 'No description'}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={() => setShowEditSite(true)}>
                        <CreditCard className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="overview">
                    <TabsList>
                      <TabsTrigger value="overview">Overview</TabsTrigger>
                      <TabsTrigger value="domains">Domains</TabsTrigger>
                      <TabsTrigger value="settings">Settings</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="overview" className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium">Primary URL</label>
                          <div className="flex items-center gap-2 mt-1">
                            <code className="text-sm bg-muted px-2 py-1 rounded">
                              https://{selectedSite.subdomain}.blog.com
                            </code>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(`https://${selectedSite.subdomain}.blog.com`)}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Theme</label>
                          <p className="text-sm mt-1 capitalize">{selectedSite.theme}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Created</label>
                          <p className="text-sm mt-1">
                            {new Date(selectedSite.created_at!).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Status</label>
                          <div className="mt-1">
                            {getStatusBadge(selectedSite.is_active ? 'active' : 'inactive')}
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="domains" className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">Custom Domains</h4>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setShowDomainDialog(true)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Domain
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        {domains.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            <Globe className="h-8 w-8 mx-auto mb-2" />
                            <p>No custom domains configured</p>
                          </div>
                        ) : (
                          domains.map((domain) => (
                            <div key={domain.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                              <div>
                                <p className="font-medium">{domain.domain}</p>
                                <p className="text-sm text-muted-foreground">
                                  Added {new Date(domain.created_at!).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                {getStatusBadge(domain.verification_status!)}
                                {domain.verification_status === 'pending' && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleVerifyDomain(domain.id!)}
                                  >
                                    <Check className="h-4 w-4 mr-2" />
                                    Verify
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="settings" className="space-y-4">
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Site Title</label>
                          <p className="text-sm mt-1">{selectedSite.site_title || 'Not set'}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Tagline</label>
                          <p className="text-sm mt-1">{selectedSite.site_tagline || 'Not set'}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Google Analytics</label>
                          <p className="text-sm mt-1">
                            {selectedSite.google_analytics_id || 'Not configured'}
                          </p>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}

      {/* Create Site Dialog */}
      <Dialog open={showCreateSite} onOpenChange={setShowCreateSite}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Site</DialogTitle>
            <DialogDescription>
              Set up a new published site for your blog content
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Site Name *</label>
              <Input
                placeholder="My Awesome Blog"
                value={newSite.site_name}
                onChange={(e) => setNewSite(prev => ({ ...prev, site_name: e.target.value }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Subdomain *</label>
              <div className="flex items-center gap-2">
                <Input
                  placeholder="myblog"
                  value={newSite.subdomain}
                  onChange={(e) => setNewSite(prev => ({ ...prev, subdomain: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') }))}
                />
                <span className="text-sm text-muted-foreground">.blog.com</span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                placeholder="Brief description of your blog"
                value={newSite.site_description}
                onChange={(e) => setNewSite(prev => ({ ...prev, site_description: e.target.value }))}
                rows={3}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowCreateSite(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateSite}>
                Create Site
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Site Dialog */}
      <Dialog open={showEditSite} onOpenChange={setShowEditSite}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Site</DialogTitle>
            <DialogDescription>
              Update your site configuration
            </DialogDescription>
          </DialogHeader>
          {selectedSite && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Site Name</label>
                <Input
                  value={selectedSite.site_name}
                  onChange={(e) => setSelectedSite(prev => prev ? { ...prev, site_name: e.target.value } : null)}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  value={selectedSite.site_description || ''}
                  onChange={(e) => setSelectedSite(prev => prev ? { ...prev, site_description: e.target.value } : null)}
                  rows={3}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Site Title</label>
                <Input
                  value={selectedSite.site_title || ''}
                  onChange={(e) => setSelectedSite(prev => prev ? { ...prev, site_title: e.target.value } : null)}
                  placeholder="SEO title for your site"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tagline</label>
                <Input
                  value={selectedSite.site_tagline || ''}
                  onChange={(e) => setSelectedSite(prev => prev ? { ...prev, site_tagline: e.target.value } : null)}
                  placeholder="Brief tagline or motto"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setShowEditSite(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateSite}>
                  Save Changes
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Domain Dialog */}
      <Dialog open={showDomainDialog} onOpenChange={setShowDomainDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Custom Domain</DialogTitle>
            <DialogDescription>
              Connect your own domain to this site
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Domain Name</label>
              <Input
                placeholder="example.com"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value.toLowerCase())}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Enter your domain without https:// or www
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowDomainDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddDomain}>
                Add Domain
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}