# Solar app template

Monorepo template for Solar apps running on microVMs.