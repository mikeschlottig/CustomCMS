from solar.access import public
from core.blog_post import BlogPost
from core.generated_image import GeneratedImage
from solar.media import generate_presigned_url
from typing import Optional, List
from datetime import datetime
import uuid
import re

def create_slug(title: str) -> str:
    """
    Convert a title to a URL-friendly slug.
    """
    # Convert to lowercase and replace spaces with hyphens
    slug = re.sub(r'[^a-zA-Z0-9\s-]', '', title.lower())
    slug = re.sub(r'\s+', '-', slug.strip())
    slug = re.sub(r'-+', '-', slug)  # Remove multiple consecutive hyphens
    return slug.strip('-')

@public
def create_blog_post(
    title: str,
    content: str,
    excerpt: Optional[str] = None,
    featured_image_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    categories: Optional[List[str]] = None,
    meta_title: Optional[str] = None,
    meta_description: Optional[str] = None,
    custom_path: Optional[str] = None,
    author_name: str = "Admin",
    author_email: Optional[str] = None
) -> BlogPost:
    """
    Create a new blog post in draft status.
    
    Args:
        title: The blog post title
        content: Markdown content of the post
        excerpt: Short description/summary
        featured_image_id: UUID of a generated image to use as featured image
        tags: List of tags for the post
        categories: List of categories for the post
        meta_title: SEO title (defaults to title if not provided)
        meta_description: SEO description
        custom_path: Custom URL path (defaults to slug if not provided)
        author_name: Author's name
        author_email: Author's email
    
    Returns:
        Created BlogPost object
    """
    # Create slug from title
    slug = create_slug(title)
    
    # Handle featured image
    featured_image_path = None
    if featured_image_id:
        try:
            image_uuid = uuid.UUID(featured_image_id)
            image_results = GeneratedImage.sql(
                "SELECT image_path FROM generated_images WHERE id = %(id)s",
                {"id": image_uuid}
            )
            if image_results:
                featured_image_path = image_results[0]['image_path']
        except ValueError:
            pass  # Invalid UUID, ignore
    
    # Create the blog post
    blog_post = BlogPost(
        title=title,
        content=content,
        slug=slug,
        excerpt=excerpt,
        featured_image_path=featured_image_path,
        status="draft",
        meta_title=meta_title or title,
        meta_description=meta_description,
        tags=tags or [],
        categories=categories or [],
        custom_path=custom_path or slug,
        author_name=author_name,
        author_email=author_email
    )
    
    blog_post.sync()
    return blog_post

@public
def update_blog_post(
    post_id: str,
    title: Optional[str] = None,
    content: Optional[str] = None,
    excerpt: Optional[str] = None,
    featured_image_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    categories: Optional[List[str]] = None,
    meta_title: Optional[str] = None,
    meta_description: Optional[str] = None,
    custom_path: Optional[str] = None,
    status: Optional[str] = None
) -> Optional[BlogPost]:
    """
    Update an existing blog post.
    
    Args:
        post_id: UUID of the blog post to update
        Other args: Fields to update (only provided fields will be updated)
    
    Returns:
        Updated BlogPost object or None if not found
    """
    try:
        post_uuid = uuid.UUID(post_id)
        
        # Get existing post
        results = BlogPost.sql(
            "SELECT * FROM blog_posts WHERE id = %(id)s",
            {"id": post_uuid}
        )
        
        if not results:
            return None
        
        blog_post = BlogPost(**results[0])
        
        # Update fields if provided
        if title is not None:
            blog_post.title = title
            blog_post.slug = create_slug(title)
        
        if content is not None:
            blog_post.content = content
        
        if excerpt is not None:
            blog_post.excerpt = excerpt
        
        if featured_image_id is not None:
            # Handle featured image
            featured_image_path = None
            if featured_image_id:  # Not empty string
                try:
                    image_uuid = uuid.UUID(featured_image_id)
                    image_results = GeneratedImage.sql(
                        "SELECT image_path FROM generated_images WHERE id = %(id)s",
                        {"id": image_uuid}
                    )
                    if image_results:
                        featured_image_path = image_results[0]['image_path']
                except ValueError:
                    pass
            blog_post.featured_image_path = featured_image_path
        
        if tags is not None:
            blog_post.tags = tags
        
        if categories is not None:
            blog_post.categories = categories
        
        if meta_title is not None:
            blog_post.meta_title = meta_title
        
        if meta_description is not None:
            blog_post.meta_description = meta_description
        
        if custom_path is not None:
            blog_post.custom_path = custom_path
        
        if status is not None:
            blog_post.status = status
            # Set published_at when publishing
            if status == "published" and blog_post.published_at is None:
                blog_post.published_at = datetime.now()
        
        # Update timestamp
        blog_post.updated_at = datetime.now()
        
        blog_post.sync()
        return blog_post
        
    except ValueError:
        return None

@public
def get_blog_posts(status: Optional[str] = None, limit: int = 50, offset: int = 0) -> List[BlogPost]:
    """
    Retrieve blog posts with optional filtering.
    
    Args:
        status: Filter by status (draft, published, archived)
        limit: Maximum number of posts to return
        offset: Number of posts to skip
    
    Returns:
        List of BlogPost objects with presigned URLs for featured images
    """
    if status:
        results = BlogPost.sql(
            "SELECT * FROM blog_posts WHERE status = %(status)s ORDER BY created_at DESC LIMIT %(limit)s OFFSET %(offset)s",
            {"status": status, "limit": limit, "offset": offset}
        )
    else:
        results = BlogPost.sql(
            "SELECT * FROM blog_posts ORDER BY created_at DESC LIMIT %(limit)s OFFSET %(offset)s",
            {"limit": limit, "offset": offset}
        )
    
    # Convert to objects and add presigned URLs for featured images
    posts = []
    for result in results:
        post = BlogPost(**result)
        # Override featured image path with presigned URL if it exists
        if post.featured_image_path:
            try:
                post.featured_image_path = generate_presigned_url(post.featured_image_path)
            except:
                # If presigned URL generation fails, keep original path
                pass
        posts.append(post)
    
    return posts

@public
def get_blog_post(post_id: str) -> Optional[BlogPost]:
    """
    Get a single blog post by ID.
    
    Args:
        post_id: UUID of the blog post
    
    Returns:
        BlogPost object with presigned URL for featured image, or None if not found
    """
    try:
        post_uuid = uuid.UUID(post_id)
        
        results = BlogPost.sql(
            "SELECT * FROM blog_posts WHERE id = %(id)s",
            {"id": post_uuid}
        )
        
        if not results:
            return None
        
        post = BlogPost(**results[0])
        
        # Override featured image path with presigned URL if it exists
        if post.featured_image_path:
            try:
                post.featured_image_path = generate_presigned_url(post.featured_image_path)
            except:
                pass
        
        return post
        
    except ValueError:
        return None

@public
def delete_blog_post(post_id: str) -> bool:
    """
    Delete a blog post.
    
    Args:
        post_id: UUID of the blog post to delete
    
    Returns:
        True if deleted successfully, False otherwise
    """
    try:
        post_uuid = uuid.UUID(post_id)
        
        result = BlogPost.sql(
            "DELETE FROM blog_posts WHERE id = %(id)s",
            {"id": post_uuid}
        )
        
        return True
        
    except (ValueError, Exception):
        return False

@public
def publish_blog_post(post_id: str) -> Optional[BlogPost]:
    """
    Publish a blog post (change status to published and set published_at).
    
    Args:
        post_id: UUID of the blog post to publish
    
    Returns:
        Updated BlogPost object or None if not found
    """
    return update_blog_post(post_id, status="published")