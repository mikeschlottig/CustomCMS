from solar.access import public
from core.published_site import PublishedSite
from core.custom_domain import CustomDomain
from core.blog_post import BlogPost
from solar.media import generate_presigned_url
from typing import Optional, List, Dict
from datetime import datetime
import uuid
import secrets
import hashlib

def generate_verification_token() -> str:
    """
    Generate a secure verification token for domain verification.
    """
    return secrets.token_urlsafe(32)

@public
def create_published_site(
    site_name: str,
    subdomain: str,
    site_description: Optional[str] = None,
    site_title: Optional[str] = None,
    site_tagline: Optional[str] = None,
    theme: str = "default"
) -> PublishedSite:
    """
    Create a new published site configuration.
    
    Args:
        site_name: Display name of the site
        subdomain: Unique subdomain identifier
        site_description: Description of the site
        site_title: SEO title for the site
        site_tagline: Site tagline/motto
        theme: Theme to use for the site
    
    Returns:
        Created PublishedSite object
    """
    # Ensure subdomain is URL-safe
    subdomain = subdomain.lower().replace(' ', '-')
    
    site = PublishedSite(
        site_name=site_name,
        site_description=site_description,
        subdomain=subdomain,
        theme=theme,
        site_title=site_title or site_name,
        site_tagline=site_tagline
    )
    
    site.sync()
    return site

@public
def update_published_site(
    site_id: str,
    site_name: Optional[str] = None,
    site_description: Optional[str] = None,
    site_title: Optional[str] = None,
    site_tagline: Optional[str] = None,
    theme: Optional[str] = None,
    is_active: Optional[bool] = None,
    social_links: Optional[Dict] = None
) -> Optional[PublishedSite]:
    """
    Update a published site configuration.
    
    Args:
        site_id: UUID of the site to update
        Other args: Fields to update
    
    Returns:
        Updated PublishedSite object or None if not found
    """
    try:
        site_uuid = uuid.UUID(site_id)
        
        results = PublishedSite.sql(
            "SELECT * FROM published_sites WHERE id = %(id)s",
            {"id": site_uuid}
        )
        
        if not results:
            return None
        
        site = PublishedSite(**results[0])
        
        # Update fields if provided
        if site_name is not None:
            site.site_name = site_name
        if site_description is not None:
            site.site_description = site_description
        if site_title is not None:
            site.site_title = site_title
        if site_tagline is not None:
            site.site_tagline = site_tagline
        if theme is not None:
            site.theme = theme
        if is_active is not None:
            site.is_active = is_active
        if social_links is not None:
            site.social_links = social_links
        
        site.updated_at = datetime.now()
        site.sync()
        
        return site
        
    except ValueError:
        return None

@public
def get_published_sites() -> List[PublishedSite]:
    """
    Get all published sites.
    
    Returns:
        List of PublishedSite objects with presigned URLs for media
    """
    results = PublishedSite.sql(
        "SELECT * FROM published_sites ORDER BY created_at DESC"
    )
    
    sites = []
    for result in results:
        site = PublishedSite(**result)
        
        # Generate presigned URLs for logo and favicon if they exist
        if site.logo_path:
            try:
                site.logo_path = generate_presigned_url(site.logo_path)
            except:
                pass
        
        if site.favicon_path:
            try:
                site.favicon_path = generate_presigned_url(site.favicon_path)
            except:
                pass
        
        sites.append(site)
    
    return sites

@public
def get_published_site(site_id: str) -> Optional[PublishedSite]:
    """
    Get a single published site by ID.
    
    Args:
        site_id: UUID of the site
    
    Returns:
        PublishedSite object or None if not found
    """
    try:
        site_uuid = uuid.UUID(site_id)
        
        results = PublishedSite.sql(
            "SELECT * FROM published_sites WHERE id = %(id)s",
            {"id": site_uuid}
        )
        
        if not results:
            return None
        
        site = PublishedSite(**results[0])
        
        # Generate presigned URLs for media
        if site.logo_path:
            try:
                site.logo_path = generate_presigned_url(site.logo_path)
            except:
                pass
        
        if site.favicon_path:
            try:
                site.favicon_path = generate_presigned_url(site.favicon_path)
            except:
                pass
        
        return site
        
    except ValueError:
        return None

@public
def add_custom_domain(site_id: str, domain: str) -> Optional[CustomDomain]:
    """
    Add a custom domain to a published site.
    
    Args:
        site_id: UUID of the site
        domain: Custom domain to add
    
    Returns:
        Created CustomDomain object or None if site not found
    """
    try:
        site_uuid = uuid.UUID(site_id)
        
        # Verify site exists
        site_results = PublishedSite.sql(
            "SELECT id FROM published_sites WHERE id = %(id)s",
            {"id": site_uuid}
        )
        
        if not site_results:
            return None
        
        # Create custom domain record
        custom_domain = CustomDomain(
            domain=domain.lower(),
            site_id=site_uuid,
            verification_token=generate_verification_token()
        )
        
        custom_domain.sync()
        return custom_domain
        
    except ValueError:
        return None

@public
def verify_custom_domain(domain_id: str) -> Optional[CustomDomain]:
    """
    Verify a custom domain (simulate DNS verification).
    
    Args:
        domain_id: UUID of the custom domain
    
    Returns:
        Updated CustomDomain object or None if not found
    """
    try:
        domain_uuid = uuid.UUID(domain_id)
        
        results = CustomDomain.sql(
            "SELECT * FROM custom_domains WHERE id = %(id)s",
            {"id": domain_uuid}
        )
        
        if not results:
            return None
        
        domain = CustomDomain(**results[0])
        
        # Simulate verification (in real implementation, check DNS records)
        domain.verification_status = "verified"
        domain.dns_records_configured = True
        domain.ssl_status = "active"
        domain.verified_at = datetime.now()
        
        domain.sync()
        return domain
        
    except ValueError:
        return None

@public
def get_site_domains(site_id: str) -> List[CustomDomain]:
    """
    Get all custom domains for a site.
    
    Args:
        site_id: UUID of the site
    
    Returns:
        List of CustomDomain objects
    """
    try:
        site_uuid = uuid.UUID(site_id)
        
        results = CustomDomain.sql(
            "SELECT * FROM custom_domains WHERE site_id = %(site_id)s ORDER BY created_at DESC",
            {"site_id": site_uuid}
        )
        
        return [CustomDomain(**result) for result in results]
        
    except ValueError:
        return []

@public
def get_site_with_posts(site_id: str) -> Optional[Dict]:
    """
    Get a site with its published blog posts for rendering.
    
    Args:
        site_id: UUID of the site
    
    Returns:
        Dictionary with site info and published posts
    """
    site = get_published_site(site_id)
    if not site:
        return None
    
    # Get published posts
    posts = BlogPost.sql(
        "SELECT * FROM blog_posts WHERE status = 'published' ORDER BY published_at DESC"
    )
    
    # Convert posts and add presigned URLs
    post_objects = []
    for post_data in posts:
        post = BlogPost(**post_data)
        if post.featured_image_path:
            try:
                post.featured_image_path = generate_presigned_url(post.featured_image_path)
            except:
                pass
        post_objects.append(post)
    
    return {
        "site": site,
        "posts": post_objects
    }