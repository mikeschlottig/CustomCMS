from solar import Table, ColumnDetails
from typing import Optional, Dict
from datetime import datetime
import uuid

class PublishedSite(Table):
    __tablename__ = "published_sites"
    
    id: uuid.UUID = ColumnDetails(default_factory=uuid.uuid4, primary_key=True)
    site_name: str
    site_description: Optional[str] = None
    
    # Domain configuration
    primary_domain: Optional[str] = None  # Custom domain
    subdomain: str  # Unique subdomain slug
    
    # Site configuration
    theme: str = "default"
    logo_path: Optional[str] = None
    favicon_path: Optional[str] = None
    
    # SEO and social
    site_title: Optional[str] = None
    site_tagline: Optional[str] = None
    social_links: Dict = {}  # JSON object for social media links
    
    # Publishing settings
    is_active: bool = True
    password_protected: bool = False
    password_hash: Optional[str] = None
    
    # Analytics
    google_analytics_id: Optional[str] = None
    
    created_at: datetime = ColumnDetails(default_factory=datetime.now)
    updated_at: datetime = ColumnDetails(default_factory=datetime.now)