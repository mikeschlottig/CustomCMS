import base64
import os
from openai import OpenAI
from solar.media import MediaFile, save_to_bucket, generate_presigned_url
from solar.access import public
from core.generated_image import GeneratedImage
from typing import Optional
import uuid

# Initialize OpenAI client with environment variable (will be None if not set)
_openai_api_key = os.getenv('OPENAI_API_KEY')
client = OpenAI(api_key=_openai_api_key) if _openai_api_key else None

@public
def generate_image(prompt: str, size: str = "1024x1024", model: str = "dall-e-3", blog_post_id: Optional[str] = None) -> GeneratedImage:
    """
    Generate an AI image using the specified prompt and save it to the media bucket.
    
    Args:
        prompt: Description of the image to generate (max 4000 chars for DALL-E 3)
        size: Image dimensions (1024x1024, 1792x1024, or 1024x1792 for DALL-E 3)
        model: AI model to use (dall-e-3 or gpt-image-1)
        blog_post_id: Optional UUID of associated blog post
    
    Returns:
        GeneratedImage object with presigned URL for the generated image
    """
    # Check if OpenAI client is available
    if not client:
        raise ValueError("OpenAI API key not configured. Please set the OPENAI_API_KEY environment variable.")
    
    # Validate size for the model
    valid_sizes = {
        "dall-e-3": ["1024x1024", "1792x1024", "1024x1792"],
        "gpt-image-1": ["1024x1024", "1536x1024", "1024x1536"]
    }
    
    if size not in valid_sizes.get(model, []):
        raise ValueError(f"Invalid size {size} for model {model}. Valid sizes: {valid_sizes.get(model, [])}")
    
    # Generate the image
    img = client.images.generate(
        model=model,
        prompt=prompt,
        n=1,
        size=size,
        response_format="b64_json"
    )
    
    # Decode and save the image
    image_bytes = base64.b64decode(img.data[0].b64_json)
    image_output = MediaFile(
        size=len(image_bytes),
        mime_type="image/png",  # DALL-E returns PNG images by default
        bytes=image_bytes
    )
    
    # Save to bucket with a descriptive filename
    file_path = f"generated-images/{uuid.uuid4()}.png"
    image_path = save_to_bucket(image_output, file_path)
    
    # Create database record
    blog_post_uuid = None
    if blog_post_id:
        try:
            blog_post_uuid = uuid.UUID(blog_post_id)
        except ValueError:
            pass  # Invalid UUID, keep as None
    
    generated_image = GeneratedImage(
        prompt=prompt,
        image_path=image_path,
        model_used=model,
        size=size,
        blog_post_id=blog_post_uuid
    )
    generated_image.sync()
    
    # Generate presigned URL and override the path
    presigned_url = generate_presigned_url(image_path)
    generated_image.image_path = presigned_url
    
    return generated_image

@public
def get_generated_images(blog_post_id: Optional[str] = None) -> list[GeneratedImage]:
    """
    Retrieve generated images, optionally filtered by blog post.
    
    Args:
        blog_post_id: Optional UUID to filter images by blog post
    
    Returns:
        List of GeneratedImage objects with presigned URLs
    """
    if blog_post_id:
        try:
            blog_post_uuid = uuid.UUID(blog_post_id)
            results = GeneratedImage.sql(
                "SELECT * FROM generated_images WHERE blog_post_id = %(blog_post_id)s ORDER BY created_at DESC",
                {"blog_post_id": blog_post_uuid}
            )
        except ValueError:
            return []  # Invalid UUID
    else:
        results = GeneratedImage.sql(
            "SELECT * FROM generated_images ORDER BY created_at DESC"
        )
    
    # Convert to objects and add presigned URLs
    images = []
    for result in results:
        image = GeneratedImage(**result)
        # Override with presigned URL
        image.image_path = generate_presigned_url(image.image_path)
        images.append(image)
    
    return images

@public
def delete_generated_image(image_id: str) -> bool:
    """
    Delete a generated image from both database and media bucket.
    
    Args:
        image_id: UUID of the image to delete
    
    Returns:
        True if deleted successfully, False otherwise
    """
    try:
        image_uuid = uuid.UUID(image_id)
        
        # Get the image record
        results = GeneratedImage.sql(
            "SELECT * FROM generated_images WHERE id = %(id)s",
            {"id": image_uuid}
        )
        
        if not results:
            return False
        
        image = GeneratedImage(**results[0])
        
        # Delete from bucket (using the stored path, not presigned URL)
        from solar.media import delete_from_bucket
        delete_from_bucket(image.image_path)
        
        # Delete from database
        GeneratedImage.sql(
            "DELETE FROM generated_images WHERE id = %(id)s",
            {"id": image_uuid}
        )
        
        return True
        
    except (ValueError, Exception):
        return False