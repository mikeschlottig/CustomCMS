from solar import Table, ColumnDetails
from typing import Optional
from datetime import datetime
import uuid

class GeneratedImage(Table):
    __tablename__ = "generated_images"
    
    id: uuid.UUID = ColumnDetails(default_factory=uuid.uuid4, primary_key=True)
    prompt: str  # The prompt used to generate the image
    image_path: str  # Path to the generated image in media bucket
    model_used: str = "dall-e-3"  # AI model used for generation
    size: str = "1024x1024"  # Image dimensions
    
    # Optional association with blog post
    blog_post_id: Optional[uuid.UUID] = None
    
    # Metadata
    alt_text: Optional[str] = None
    tags: Optional[str] = None  # Space-separated tags for organization
    
    created_at: datetime = ColumnDetails(default_factory=datetime.now)