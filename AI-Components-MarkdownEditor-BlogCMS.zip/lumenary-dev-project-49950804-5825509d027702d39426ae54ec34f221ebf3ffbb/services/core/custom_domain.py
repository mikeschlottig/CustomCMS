from solar import Table, ColumnDetails
from typing import Optional
from datetime import datetime
import uuid

class CustomDomain(Table):
    __tablename__ = "custom_domains"
    
    id: uuid.UUID = ColumnDetails(default_factory=uuid.uuid4, primary_key=True)
    domain: str  # The custom domain (e.g., myblog.com)
    site_id: uuid.UUID  # Reference to published_sites
    
    # Domain verification
    verification_status: str = "pending"  # pending, verified, failed
    verification_token: str
    dns_records_configured: bool = False
    
    # SSL/TLS
    ssl_status: str = "pending"  # pending, active, failed
    ssl_expires_at: Optional[datetime] = None
    
    # Redirect settings
    redirect_to_https: bool = True
    redirect_www: bool = False  # Redirect www to non-www or vice versa
    
    created_at: datetime = ColumnDetails(default_factory=datetime.now)
    verified_at: Optional[datetime] = None