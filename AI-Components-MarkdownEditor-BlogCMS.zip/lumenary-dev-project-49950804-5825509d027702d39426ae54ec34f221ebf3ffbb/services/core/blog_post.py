from solar import Table, ColumnDetails
from typing import Optional, List, Dict
from datetime import datetime
import uuid

class BlogPost(Table):
    __tablename__ = "blog_posts"
    
    id: uuid.UUID = ColumnDetails(default_factory=uuid.uuid4, primary_key=True)
    title: str
    content: str  # Markdown content
    slug: str  # URL-friendly version of title
    excerpt: Optional[str] = None
    featured_image_path: Optional[str] = None  # Path to featured image
    status: str = "draft"  # draft, published, archived
    
    # SEO fields
    meta_title: Optional[str] = None
    meta_description: Optional[str] = None
    tags: List[str] = []  # Array of tags
    categories: List[str] = []  # Array of categories
    
    # Publishing fields
    published_at: Optional[datetime] = None
    custom_domain: Optional[str] = None
    custom_path: Optional[str] = None  # Custom URL path
    
    # Timestamps
    created_at: datetime = ColumnDetails(default_factory=datetime.now)
    updated_at: datetime = ColumnDetails(default_factory=datetime.now)
    
    # Author info (can be extended later for multi-user)
    author_name: str = "Admin"
    author_email: Optional[str] = None